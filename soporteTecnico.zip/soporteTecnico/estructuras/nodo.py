class Nodo:
    """Nodo genérico: guarda un dato y la referencia al siguiente nodo."""

    def __init__(self, dato):
        self.dato = dato
        self.siguiente = None
