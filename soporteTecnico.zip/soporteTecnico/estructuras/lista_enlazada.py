from estructuras.nodo import Nodo


class ListaEnlazada:
    """Lista simplemente enlazada. Se usa para pendientes y canceladas.

    Eficiencia:
        insertar_final  O(1)  (se mantiene referencia al último nodo)
        insertar_inicio O(1)
        buscar          O(n)
        eliminar        O(n)  (hay que localizar el nodo anterior)
        mostrar         O(n)
    """

    def __init__(self):
        self.cabeza = None
        self.cola = None       # referencia al último nodo
        self.tamano = 0

    def esta_vacia(self):
        return self.cabeza is None

    def insertar_final(self, dato):
        nuevo = Nodo(dato)
        if self.cabeza is None:
            self.cabeza = nuevo
            self.cola = nuevo
        else:
            self.cola.siguiente = nuevo
            self.cola = nuevo
        self.tamano += 1

    def insertar_inicio(self, dato):
        nuevo = Nodo(dato)
        nuevo.siguiente = self.cabeza
        self.cabeza = nuevo
        if self.cola is None:
            self.cola = nuevo
        self.tamano += 1

    def buscar(self, codigo):
        """Recorre la lista y devuelve el dato, o None si no existe."""
        actual = self.cabeza
        while actual is not None:
            if actual.dato.codigo == codigo:
                return actual.dato
            actual = actual.siguiente
        return None

    def eliminar(self, codigo):
        """Elimina el nodo manipulando los enlaces. Devuelve el dato o None."""
        anterior = None
        actual = self.cabeza
        while actual is not None:
            if actual.dato.codigo == codigo:
                if anterior is None:
                    self.cabeza = actual.siguiente
                else:
                    anterior.siguiente = actual.siguiente
                if actual is self.cola:
                    self.cola = anterior
                actual.siguiente = None
                self.tamano -= 1
                return actual.dato
            anterior = actual
            actual = actual.siguiente
        return None

    def mostrar(self):
        actual = self.cabeza
        while actual is not None:
            actual.dato.mostrar()
            print("  " + "-" * 30)
            actual = actual.siguiente

    def mostrar_grafico(self):
        """Muestra la lista como [101] -> [105] -> None"""
        texto = ""
        actual = self.cabeza
        while actual is not None:
            texto += f"[Solicitud {actual.dato.codigo}] -> "
            actual = actual.siguiente
        print(texto + "None")
