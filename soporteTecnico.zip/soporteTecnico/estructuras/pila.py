from estructuras.nodo import Nodo


class Pila:
    """Pila LIFO: la última solicitud atendida es la primera en recuperarse.

    Eficiencia:
        apilar / desapilar   O(1)
        tope                 O(1)
        buscar / mostrar     O(n)
    """

    def __init__(self):
        self._tope = None
        self.tamano = 0

    def esta_vacia(self):
        return self._tope is None

    def apilar(self, dato):
        nuevo = Nodo(dato)
        nuevo.siguiente = self._tope
        self._tope = nuevo
        self.tamano += 1

    def desapilar(self):
        if self.esta_vacia():
            return None
        nodo = self._tope
        self._tope = nodo.siguiente
        nodo.siguiente = None
        self.tamano -= 1
        return nodo.dato

    def tope(self):
        if self.esta_vacia():
            return None
        return self._tope.dato

    def buscar(self, codigo):
        """Recorre la pila sin modificarla."""
        actual = self._tope
        while actual is not None:
            if actual.dato.codigo == codigo:
                return actual.dato
            actual = actual.siguiente
        return None

    def mostrar(self):
        if self.esta_vacia():
            print("  El historial está vacío.")
            return
        posicion = 1
        actual = self._tope
        while actual is not None:
            s = actual.dato
            print(f"  {posicion}. Solicitud {s.codigo} - {s.usuario} "
                  f"(Técnico: {s.tecnico})")
            posicion += 1
            actual = actual.siguiente
