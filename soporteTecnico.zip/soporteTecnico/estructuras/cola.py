from estructuras.nodo import Nodo


class Cola:
    """Cola FIFO: la primera solicitud que entra es la primera en atenderse.

    Eficiencia:
        encolar / desencolar   O(1)
        encolar_al_frente      O(1)
        frente                 O(1)
        eliminar                O(n)
        mostrar                 O(n)
    """

    def __init__(self):
        self._inicio = None
        self._fin = None
        self.tamano = 0

    def esta_vacia(self):
        return self._inicio is None

    def encolar(self, dato):
        nuevo = Nodo(dato)
        if self._fin is None:
            self._inicio = nuevo
            self._fin = nuevo
        else:
            self._fin.siguiente = nuevo
            self._fin = nuevo
        self.tamano += 1

    def encolar_al_frente(self, dato):
        """Reinserta un dato al frente (usado al deshacer una atención)."""
        nuevo = Nodo(dato)
        nuevo.siguiente = self._inicio
        self._inicio = nuevo
        if self._fin is None:
            self._fin = nuevo
        self.tamano += 1

    def desencolar(self):
        if self.esta_vacia():
            return None
        nodo = self._inicio
        self._inicio = nodo.siguiente
        if self._inicio is None:
            self._fin = None
        nodo.siguiente = None
        self.tamano -= 1
        return nodo.dato

    def frente(self):
        if self.esta_vacia():
            return None
        return self._inicio.dato

    def eliminar(self, codigo):
        """Quita de la cola una solicitud cancelada (manipulando enlaces)."""
        anterior = None
        actual = self._inicio
        while actual is not None:
            if actual.dato.codigo == codigo:
                if anterior is None:
                    self._inicio = actual.siguiente
                else:
                    anterior.siguiente = actual.siguiente
                if actual is self._fin:
                    self._fin = anterior
                actual.siguiente = None
                self.tamano -= 1
                return True
            anterior = actual
            actual = actual.siguiente
        return False

    def mostrar(self):
        if self.esta_vacia():
            print("  La cola está vacía.")
            return
        texto = "FRENTE -> "
        actual = self._inicio
        while actual is not None:
            texto += f"[{actual.dato.codigo}] -> "
            actual = actual.siguiente
        print("  " + texto + "FIN")
