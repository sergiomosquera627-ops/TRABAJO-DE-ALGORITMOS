class Solicitud:
    """Información de una solicitud de soporte técnico."""

    def __init__(self, codigo, usuario, problema, prioridad):
        self.codigo = codigo
        self.usuario = usuario
        self.problema = problema
        self.prioridad = prioridad      # Alta, Media o Baja
        self.estado = "PENDIENTE"       # PENDIENTE, ATENDIDA o CANCELADA
        self.tecnico = "Sin asignar"

    def mostrar(self):
        print(f"  Código:    {self.codigo}")
        print(f"  Usuario:   {self.usuario}")
        print(f"  Problema:  {self.problema}")
        print(f"  Prioridad: {self.prioridad}")
        print(f"  Estado:    {self.estado}")
        print(f"  Técnico:   {self.tecnico}")
