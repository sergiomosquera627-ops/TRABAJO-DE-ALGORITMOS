from modelos.solicitud import Solicitud

__all__ = ["Solicitud"]
