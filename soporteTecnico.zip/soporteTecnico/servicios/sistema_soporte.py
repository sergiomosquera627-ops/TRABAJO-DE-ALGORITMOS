from estructuras import ListaEnlazada, Cola, Pila
from modelos import Solicitud


class SistemaSoporte:
    """Reúne las estructuras dinámicas y la lógica del centro de soporte."""

    def __init__(self):
        self.pendientes = ListaEnlazada()   # solicitudes pendientes
        self.cola = Cola()                  # orden de atención (FIFO)
        self.historial = Pila()             # solicitudes atendidas (LIFO)
        self.canceladas = ListaEnlazada()   # solicitudes canceladas
        self.total_registradas = 0
        self.prioridad_alta = 0
        self.prioridad_media = 0
        self.prioridad_baja = 0

    #  utilidades 
    def codigo_existe(self, codigo):
        """El código debe ser único en TODAS las estructuras."""
        return (self.pendientes.buscar(codigo) is not None
                or self.historial.buscar(codigo) is not None
                or self.canceladas.buscar(codigo) is not None)

    def _contar_prioridad(self, prioridad, delta):
        if prioridad == "Alta":
            self.prioridad_alta += delta
        elif prioridad == "Media":
            self.prioridad_media += delta
        else:
            self.prioridad_baja += delta

    #  opción 1 
    def registrar(self):
        print("\n--- REGISTRAR SOLICITUD ---")
        codigo = input("Código: ").strip()
        if codigo == "":
            print("El código no puede estar vacío.")
            return
        if self.codigo_existe(codigo):
            print("Error: ya existe una solicitud con ese código.")
            return
        usuario = input("Usuario: ").strip()
        problema = input("Descripción del problema: ").strip()
        if usuario == "" or problema == "":
            print("El usuario y el problema no pueden estar vacíos.")
            return
        prioridad = input("Prioridad (Alta/Media/Baja): ").strip().capitalize()
        if prioridad not in ("Alta", "Media", "Baja"):
            print("Prioridad inválida. Use Alta, Media o Baja.")
            return

        solicitud = Solicitud(codigo, usuario, problema, prioridad)
        self.pendientes.insertar_final(solicitud)
        self.cola.encolar(solicitud)
        self.total_registradas += 1
        self._contar_prioridad(prioridad, 1)
        print("Solicitud registrada correctamente.")

    # opción 2 
    def mostrar_pendientes(self):
        print("\nSOLICITUDES PENDIENTES")
        if self.pendientes.esta_vacia():
            print("  No hay solicitudes pendientes.")
            return
        self.pendientes.mostrar()
        print("Estructura (lista enlazada):")
        print("  ", end="")
        self.pendientes.mostrar_grafico()
        print("Orden de atención (cola):")
        self.cola.mostrar()

    #  opción 3 
    def buscar(self):
        print("\n--- BUSCAR SOLICITUD ---")
        codigo = input("Código a buscar: ").strip()
        solicitud = self.pendientes.buscar(codigo)
        if solicitud is None:
            solicitud = self.historial.buscar(codigo)
        if solicitud is None:
            solicitud = self.canceladas.buscar(codigo)
        if solicitud is None:
            print("Solicitud no encontrada.")
        else:
            print("Solicitud encontrada:")
            solicitud.mostrar()

    # opción 4 
    def atender(self):
        print("\n--- ATENDER SIGUIENTE SOLICITUD ---")
        if self.cola.esta_vacia():
            print("No hay solicitudes por atender.")
            return
        tecnico = input("Nombre del técnico que atiende: ").strip()
        if tecnico == "":
            print("Debe indicar un técnico.")
            return

        solicitud = self.cola.desencolar()          # 1. sale de la cola
        self.pendientes.eliminar(solicitud.codigo)  #    y de pendientes
        solicitud.estado = "ATENDIDA"               # 2. actualizar estado
        solicitud.tecnico = tecnico                 # 3. registrar técnico
        self.historial.apilar(solicitud)            # 4. guardar en la pila

        print("\nAtendiendo solicitud...")
        print(f"Código: {solicitud.codigo}")
        print(f"Usuario: {solicitud.usuario}")
        print(f"Prioridad: {solicitud.prioridad}")
        print(f"Técnico: {solicitud.tecnico}")
        print("Solicitud atendida correctamente.")

    # opción 5 
    def cancelar(self):
        print("\n--- CANCELAR SOLICITUD ---")
        codigo = input("Código de la solicitud pendiente: ").strip()
        solicitud = self.pendientes.buscar(codigo)
        if solicitud is None:
            print("No existe una solicitud pendiente con ese código.")
            return
        print("Solicitud encontrada:")
        solicitud.mostrar()
        if input("¿Desea cancelarla? S/N: ").strip().upper() != "S":
            print("Operación cancelada por el usuario.")
            return

        self.pendientes.eliminar(codigo)   # manipulación de enlaces
        self.cola.eliminar(codigo)         # también sale de la cola
        solicitud.estado = "CANCELADA"
        self.canceladas.insertar_final(solicitud)
        print(f"La solicitud {codigo} fue cancelada correctamente.")

    #  opción 6 
    def mostrar_historial(self):
        print("\nHISTORIAL DE ATENCIONES")
        self.historial.mostrar()

    # opción 7 
    def deshacer(self):
        print("\n--- DESHACER ÚLTIMA ATENCIÓN ---")
        ultima = self.historial.tope()
        if ultima is None:
            print("No hay atenciones para deshacer.")
            return
        print("Última atención:")
        print(f"Código: {ultima.codigo}")
        print(f"Usuario: {ultima.usuario}")
        if input("¿Desea deshacer esta atención? S/N: ").strip().upper() != "S":
            print("Operación cancelada por el usuario.")
            return

        solicitud = self.historial.desapilar()      # LIFO: sale la última
        solicitud.estado = "PENDIENTE"
        solicitud.tecnico = "Sin asignar"
        self.pendientes.insertar_inicio(solicitud)  # vuelve a pendientes
        self.cola.encolar_al_frente(solicitud)      # y a ser la siguiente
        print("La atención fue deshecha.")
        print(f"La solicitud {solicitud.codigo} regresó a pendientes.")

    #  opción 8 
    def estadisticas(self):
        print("\n" + "+" * 33)
        print("ESTADÍSTICAS")
        print("+" * 33)
        print(f"Total registradas: {self.total_registradas}")
        print(f"Pendientes: {self.pendientes.tamano}")
        print(f"Atendidas: {self.historial.tamano}")
        print(f"Canceladas: {self.canceladas.tamano}")
        print(f"Prioridad alta: {self.prioridad_alta}")
        print(f"Prioridad media: {self.prioridad_media}")
        print(f"Prioridad baja: {self.prioridad_baja}")
