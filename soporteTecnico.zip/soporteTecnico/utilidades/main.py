"""
Punto de entrada del sistema.
Para ejecutarlo desde la raíz del proyecto (carpeta soporteTecnico):
    python -m utilidades.main
"""
import os
import sys


RAIZ_PROYECTO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if RAIZ_PROYECTO not in sys.path:
    sys.path.insert(0, RAIZ_PROYECTO)

from servicios import SistemaSoporte


def mostrar_menu():
    print()
    print("CENTRO DE SOPORTE TÉCNICO")
    print()
    print("1. Registrar solicitud")
    print("2. Mostrar solicitudes pendientes")
    print("3. Buscar solicitud")
    print("4. Atender siguiente solicitud")
    print("5. Cancelar solicitud")
    print("6. Mostrar historial de atenciones")
    print("7. Deshacer última atención")
    print("8. Mostrar estadísticas")
    print("9. Salir")


def main():
    sistema = SistemaSoporte()
    opcion = ""
    while opcion != "9":
        mostrar_menu()
        opcion = input("Seleccione una opción: ").strip()
        if opcion == "1":
            sistema.registrar()
        elif opcion == "2":
            sistema.mostrar_pendientes()
        elif opcion == "3":
            sistema.buscar()
        elif opcion == "4":
            sistema.atender()
        elif opcion == "5":
            sistema.cancelar()
        elif opcion == "6":
            sistema.mostrar_historial()
        elif opcion == "7":
            sistema.deshacer()
        elif opcion == "8":
            sistema.estadisticas()
        elif opcion == "9":
            print("Cerrando el sistema. ¡Hasta pronto!")
        else:
            print("Opción inválida. Intente de nuevo.")


if __name__ == "__main__":
    main()
